package com.moubitech.tests.login.notestng;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginTest {
	public static void main(String args[]) throws Exception {

		ArrayList<TestDataMap> dataRows = new TestDataMapList("input.txt");

		for (TestDataMap dataMap : dataRows) {
			WebDriver driver = new FirefoxDriver();
			TestHelper.doLoginAction(driver, dataMap);
			TestHelper.assertExpectation(driver, dataMap);
			driver.close();
		}
	}
}
