package com.moubitech.tests.login.notestng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestHelper {
	private static final String SITE_URL = "http://www.moubitech.com";
	
	private static void printTestResult(String actualResult, TestDataMap map) {
		System.out.print(map.get("testName") + "... ");
		if (actualResult.equals(map.get("expectedResult"))) {
			System.out.println("Passed");
		} else {
			System.out.println("Failed");
		}
	}

	static void assertExpectation(WebDriver driver, TestDataMap map) {
		String actualMessage = "";
		try { 
		WebElement actualMessageElement = driver.findElement(By
				.id("loginMessage"));
			actualMessage = actualMessageElement.getText();
		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println(e.getMessage());
		}
	
		printTestResult(actualMessage, map);
	}

	static void doLoginAction(WebDriver driver, TestDataMap map) {
		driver.get(SITE_URL);
		try {
			WebElement emailInput = driver.findElement(By.id("userName"));
			// if the element cannot be found, the test will naturally fail.
			emailInput.sendKeys(map.get("userName"));
	
			WebElement passwordInput = driver.findElement(By.id("password"));
			passwordInput.sendKeys(map.get("password"));
	
			WebElement loginButton = driver.findElement(By.id("loginButton"));
			loginButton.click();
		} catch (org.openqa.selenium.NoSuchElementException e) {
			System.out.println(e.getAdditionalInformation());
		}
	}

}
