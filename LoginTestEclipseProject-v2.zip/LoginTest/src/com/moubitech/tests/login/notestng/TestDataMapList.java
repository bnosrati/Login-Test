package com.moubitech.tests.login.notestng;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TestDataMapList extends ArrayList<TestDataMap> {
	private static final long serialVersionUID = 2482153735512809989L;

	TestDataMapList (String datafile) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(datafile));

		// line format is:
		// Test case name|username|password|expected result
		String line = in.readLine(); // read a line at a time
		int i = 1;
		while (line != null) {
			try {
				String[] data = line.split("\\|");
				if (data.length != 4) {
					throw new DataLineException();
				}
				add(new TestDataMap(data));				
			} catch (DataLineException e) {
				// so we can continue looking at the next lines and not stop
				// testing
				System.out
						.println("Data line["
								+ i
								+ "] is invalid. 4 parameters are expected.  Skipping test.");
			}
			i++;
			line = in.readLine();
		}
		in.close();
	}
}
