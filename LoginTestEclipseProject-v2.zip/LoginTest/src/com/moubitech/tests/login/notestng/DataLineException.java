package com.moubitech.tests.login.notestng;

public class DataLineException extends Throwable {
	private static final long serialVersionUID = 5582914483520532709L;
}
