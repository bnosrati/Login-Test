package com.moubitech.tests.login.notestng;

import java.util.HashMap;

public class TestDataMap extends HashMap<String, String> {
	private static final long serialVersionUID = -4748029780538725077L;

	TestDataMap(String[] data) throws DataLineException {
		put("testName", data[0].trim());
		put("userName", data[1].trim());
		put("password", data[2].trim());
		put("expectedResult", data[3].trim());
	}
}
